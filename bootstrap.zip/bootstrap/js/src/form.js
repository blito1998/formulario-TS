var btnSalvar = document.querySelector("#btnSalvar");

btnSalvar.addEventListener("click", function (event) {
    event.preventDefault();

    var frm = document.querySelector("#cadastro");
    console.log(cadastro.email.value);
    console.log(cadastro.Password1.value);
})